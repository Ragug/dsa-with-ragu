import { loadPyodide, type PyodideInterface } from "pyodide";
import harnessSource from "./pythonHarness.py?raw";
import type { PythonTestCase, RunOptions } from "../runtime/pythonRuntime";

type WorkerRequest = {
  id: number;
  type: "init" | "run";
  payload?: {
    code: string;
    testCase: PythonTestCase;
    functionName: string;
    options: RunOptions;
  };
};

type WorkerResponse = {
  id: number;
  type: "ready" | "result" | "error";
  payload?: unknown;
  error?: string;
};

let pyodidePromise: Promise<PyodideInterface> | null = null;

function getPyodide(): Promise<PyodideInterface> {
  if (!pyodidePromise) {
    pyodidePromise = loadPyodide().then((pyodide) => {
      // Defines `run_case` once, so it is not recompiled for every test.
      pyodide.runPython(harnessSource);
      return pyodide;
    });
  }

  return pyodidePromise;
}

function send(message: WorkerResponse) {
  self.postMessage(message);
}

self.onmessage = async (event: MessageEvent<WorkerRequest>) => {
  const { id, type, payload } = event.data;

  try {
    const pyodide = await getPyodide();

    if (type === "init") {
      send({ id, type: "ready" });
      return;
    }

    if (type !== "run" || !payload) {
      throw new Error("Invalid worker request.");
    }

    const { code, testCase, functionName, options } = payload;
    const runCase = pyodide.globals.get("run_case");

    try {
      const raw = runCase(
        code,
        functionName,
        JSON.stringify(testCase.input),
        JSON.stringify(testCase.expected),
        JSON.stringify(options ?? {}),
      ) as string;

      send({ id, type: "result", payload: JSON.parse(raw) });
    } finally {
      runCase.destroy();
    }
  } catch (error) {
    send({
      id,
      type: "error",
      error: error instanceof Error ? error.message : String(error),
    });
  }
};
