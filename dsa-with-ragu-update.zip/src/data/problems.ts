
import type { Problem } from "../types/problem";

export const problems: Problem[] = [
  {
    id: "two-sum",
    title: "Two Sum",
    topic: "Arrays",
    difficulty: "Easy",
    functionName: "two_sum",
    inputNames: ["nums", "target"],
    ignoreOrder: true,
    description:
      "Given an array of integers nums and an integer target, return the indices of two numbers that add up to target. Assume exactly one solution exists, and you cannot use the same element twice.",
    examples: [
      {
        input: [[2, 7, 11, 15], 9],
        expected: [0, 1],
      },
      {
        input: [[3, 2, 4], 6],
        expected: [1, 2],
      },
    ],
    tests: [
      {
        input: [[2, 7, 11, 15], 9],
        expected: [0, 1],
      },
      {
        input: [[3, 2, 4], 6],
        expected: [1, 2],
      },
      {
        input: [[3, 3], 6],
        expected: [0, 1],
      },
      {
        input: [[-1, -2, -3, -4, -5], -8],
        expected: [2, 4],
      },
      {
        input: [[0, 4, 3, 0], 0],
        expected: [0, 3],
      },
    ],
    constraints: [
      "2 <= nums.length <= 10^4",
      "-10^9 <= nums[i] <= 10^9",
      "-10^9 <= target <= 10^9",
      "Exactly one valid answer exists.",
      "You cannot use the same element twice.",
    ],
    starterCode:
      "def two_sum(nums, target):\n    # Write your solution here\n    pass",
  },

  {
    id: "binary-search",
    title: "Binary Search",
    topic: "Searching",
    difficulty: "Easy",
    functionName: "search",
    inputNames: ["nums", "target"],
    description:
      "Given a sorted array of integers nums and a target value, return the index of target if it exists. Otherwise, return -1. Your solution should use binary search.",
    examples: [
      {
        input: [[-1, 0, 3, 5, 9, 12], 9],
        expected: 4,
      },
      {
        input: [[-1, 0, 3, 5, 9, 12], 2],
        expected: -1,
      },
    ],
    tests: [
      {
        input: [[-1, 0, 3, 5, 9, 12], 9],
        expected: 4,
      },
      {
        input: [[-1, 0, 3, 5, 9, 12], 2],
        expected: -1,
      },
      {
        input: [[5], 5],
        expected: 0,
      },
      {
        input: [[5], -5],
        expected: -1,
      },
      {
        input: [[1, 3, 5, 7, 9], 1],
        expected: 0,
      },
      {
        input: [[1, 3, 5, 7, 9], 9],
        expected: 4,
      },
    ],
    constraints: [
      "1 <= nums.length <= 10^4",
      "All integers in nums are unique.",
      "nums is sorted in ascending order.",
      "-10^4 <= nums[i], target <= 10^4",
    ],
    starterCode:
      "def search(nums, target):\n    # Write your solution here\n    pass",
  },

  {
    id: "valid-parentheses",
    title: "Valid Parentheses",
    topic: "Stack & Queue",
    difficulty: "Easy",
    functionName: "is_valid",
    inputNames: ["s"],
    description:
      "Given a string containing only the characters '(', ')', '{', '}', '[' and ']', determine whether the input string has valid bracket ordering. Every opening bracket must be closed by the same type of bracket in the correct order.",
    examples: [
      {
        input: ["()"],
        expected: true,
      },
      {
        input: ["()[]{}"],
        expected: true,
      },
      {
        input: ["(]"],
        expected: false,
      },
    ],
    tests: [
      {
        input: ["()"],
        expected: true,
      },
      {
        input: ["()[]{}"],
        expected: true,
      },
      {
        input: ["(]"],
        expected: false,
      },
      {
        input: ["([)]"],
        expected: false,
      },
      {
        input: ["{[]}"],
        expected: true,
      },
      {
        input: ["("],
        expected: false,
      },
      {
        input: [")"],
        expected: false,
      },
    ],
    constraints: [
      "1 <= s.length <= 10^4",
      "s contains only the characters ()[]{}.",
    ],
    starterCode:
      "def is_valid(s):\n    # Write your solution here\n    pass",
  },

  {
    id: "reverse-linked-list",
    title: "Reverse Linked List",
    topic: "Linked List",
    difficulty: "Medium",
    functionName: "reverse_list",
    inputNames: ["head"],
    description:
      "Given a list of values representing a singly linked list, return the values in reverse order. For this browser-based exercise, the linked list is represented as a Python list.",
    examples: [
      {
        input: [[1, 2, 3, 4, 5]],
        expected: [5, 4, 3, 2, 1],
      },
      {
        input: [[1, 2]],
        expected: [2, 1],
      },
    ],
    tests: [
      {
        input: [[1, 2, 3, 4, 5]],
        expected: [5, 4, 3, 2, 1],
      },
      {
        input: [[1, 2]],
        expected: [2, 1],
      },
      {
        input: [[1]],
        expected: [1],
      },
      {
        input: [[]],
        expected: [],
      },
      {
        input: [[1, 2, 3]],
        expected: [3, 2, 1],
      },
    ],
    constraints: [
      "0 <= nums.length <= 5000",
      "-5000 <= nums[i] <= 5000",
      "For this exercise, the input and output are Python lists.",
    ],
    starterCode:
      "def reverse_list(head):\n    # Reverse the list and return it\n    pass",
  },

  {
    id: "maximum-subarray",
    title: "Maximum Subarray",
    topic: "Dynamic Programming",
    difficulty: "Medium",
    functionName: "max_subarray",
    inputNames: ["nums"],
    description:
      "Given an integer array nums, find the contiguous subarray with the largest sum and return that sum.",
    examples: [
      {
        input: [[-2, 1, -3, 4, -1, 2, 1, -5, 4]],
        expected: 6,
      },
      {
        input: [[1]],
        expected: 1,
      },
    ],
    tests: [
      {
        input: [[-2, 1, -3, 4, -1, 2, 1, -5, 4]],
        expected: 6,
      },
      {
        input: [[1]],
        expected: 1,
      },
      {
        input: [[5, 4, -1, 7, 8]],
        expected: 23,
      },
      {
        input: [[-1, -2, -3, -4]],
        expected: -1,
      },
      {
        input: [[-2, -1]],
        expected: -1,
      },
      {
        input: [[0, 0, 0]],
        expected: 0,
      },
    ],
    constraints: [
      "1 <= nums.length <= 10^5",
      "-10^4 <= nums[i] <= 10^4",
    ],
    starterCode:
      "def max_subarray(nums):\n    # Write your solution here\n    pass",
  },

  {
    id: "merge-sort",
    title: "Merge Sort",
    topic: "Sorting",
    difficulty: "Medium",
    functionName: "merge_sort",
    inputNames: ["nums"],
    description:
      "Given an array of integers, sort it in ascending order using the merge sort algorithm. Return the sorted array.",
    examples: [
      {
        input: [[5, 2, 3, 1]],
        expected: [1, 2, 3, 5],
      },
      {
        input: [[5, 1, 1, 2, 0, 0]],
        expected: [0, 0, 1, 1, 2, 5],
      },
    ],
    tests: [
      {
        input: [[5, 2, 3, 1]],
        expected: [1, 2, 3, 5],
      },
      {
        input: [[5, 1, 1, 2, 0, 0]],
        expected: [0, 0, 1, 1, 2, 5],
      },
      {
        input: [[1]],
        expected: [1],
      },
      {
        input: [[3, 2, 1]],
        expected: [1, 2, 3],
      },
      {
        input: [[-5, 3, 0, -1, 2]],
        expected: [-5, -1, 0, 2, 3],
      },
      {
        input: [[2, 2, 2, 2]],
        expected: [2, 2, 2, 2],
      },
    ],
    constraints: [
      "1 <= nums.length <= 5 * 10^4",
      "-5 * 10^4 <= nums[i] <= 5 * 10^4",
    ],
    starterCode:
      "def merge_sort(nums):\n    # Write your solution here\n    pass",
  },
];
