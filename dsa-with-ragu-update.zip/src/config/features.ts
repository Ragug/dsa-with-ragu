/**
 * Advanced measurement (precise timing) lives behind this flag so it can later
 * be tied to a real premium/plan check. When false, the toggle is shown locked.
 */
export const ADVANCED_METRICS_UNLOCKED = true;
