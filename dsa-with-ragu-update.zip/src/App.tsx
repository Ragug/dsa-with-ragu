import { useCallback, useEffect, useMemo, useState } from "react";
import {
  ArrowDownUp,
  Brain,
  CheckCircle2,
  GitBranch,
  GitFork,
  House,
  Layers,
  LayoutGrid,
  Link,
  Network,
  Search,
  Target,
  Text,
  Trash2,
} from "lucide-react";
import ProblemWorkspace from "./components/ProblemWorkspace";
import { problems } from "./data/problems";
import type { Problem } from "./types/problem";
import {
  isProblemSolved,
  readTheme,
  resetAllProgress,
  saveTheme,
  type AppTheme,
} from "./storage/progress";

const topicIcons: Record<string, typeof Brain> = {
  "All Problems": LayoutGrid,
  Arrays: Layers,
  Searching: Search,
  "Stack & Queue": Layers,
  "Linked List": GitBranch,
  "Dynamic Programming": Brain,
  Sorting: ArrowDownUp,
  Strings: Text,
  Trees: GitFork,
  Graphs: Network,
  "Two Pointers": ArrowDownUp,
  "Hash Table": Link,
  "Sliding Window": Target,
};

function getProblemIdFromPath(): string | null {
  const match = window.location.pathname.match(/^\/problems\/([^/]+)\/?$/);
  return match ? decodeURIComponent(match[1]) : null;
}

function getProblemPath(problem: Problem): string {
  return `/problems/${encodeURIComponent(problem.id)}/`;
}

function getThemeClass(theme: AppTheme): string {
  if (theme === "system") {
    return window.matchMedia("(prefers-color-scheme: dark)").matches
      ? "theme-dark"
      : "theme-light";
  }

  return theme === "dark" ? "theme-dark" : "theme-light";
}

export default function App() {
  const [activeTopic, setActiveTopic] = useState("All Problems");
  const [search, setSearch] = useState("");
  const [selectedProblemId, setSelectedProblemId] = useState<string | null>(
    () => getProblemIdFromPath(),
  );
  const [theme, setTheme] = useState<AppTheme>(() => readTheme());
  const [progressVersion, setProgressVersion] = useState(0);

  const topics = useMemo(
    () => [
      "All Problems",
      ...Array.from(new Set(problems.map((problem) => problem.topic))).sort(),
    ],
    [],
  );

  const selectedProblem = problems.find(
    (problem) => problem.id === selectedProblemId,
  );

  const filteredProblems = useMemo(() => {
    const query = search.trim().toLowerCase();

    return problems.filter((problem) => {
      const matchesTopic =
        activeTopic === "All Problems" || problem.topic === activeTopic;

      const matchesSearch =
        !query ||
        problem.title.toLowerCase().includes(query) ||
        problem.topic.toLowerCase().includes(query) ||
        problem.description.toLowerCase().includes(query);

      return matchesTopic && matchesSearch;
    });
  }, [activeTopic, search]);

  const completedCount = useMemo(
    () => problems.filter((problem) => isProblemSolved(problem.id)).length,
    [progressVersion],
  );

  const navigateToProblem = useCallback((problem: Problem) => {
    const path = getProblemPath(problem);

    if (window.location.pathname !== path) {
      window.history.pushState({}, "", path);
    }

    setSelectedProblemId(problem.id);
    window.scrollTo({ top: 0, behavior: "instant" });
  }, []);

  const goToList = useCallback(() => {
    window.history.pushState({}, "", "/");
    setSelectedProblemId(null);
    window.scrollTo({ top: 0, behavior: "instant" });
  }, []);

  useEffect(() => {
    function syncFromUrl() {
      const problemId = getProblemIdFromPath();

      if (problemId && problems.some((problem) => problem.id === problemId)) {
        setSelectedProblemId(problemId);
      } else {
        setSelectedProblemId(null);

        // If the URL looks like a problem URL but doesn't exist,
        // return to the problem list.
        if (problemId) {
          window.history.replaceState({}, "", "/");
        }
      }
    }

    window.addEventListener("popstate", syncFromUrl);
    return () => window.removeEventListener("popstate", syncFromUrl);
  }, []);

  useEffect(() => {
    void import("./runtime/pythonRuntime")
      .then(({ warmPythonRuntime }) => warmPythonRuntime())
      .catch(() => {
        // The workspace displays runtime errors if initialization fails.
      });
  }, []);

  useEffect(() => {
    saveTheme(theme);
  }, [theme]);

  useEffect(() => {
    if (theme !== "system") return;

    const media = window.matchMedia("(prefers-color-scheme: dark)");
    const update = () => {
      document.documentElement.dataset.theme = getThemeClass("system");
    };

    update();
    media.addEventListener("change", update);

    return () => media.removeEventListener("change", update);
  }, [theme]);

  useEffect(() => {
    document.documentElement.dataset.theme = getThemeClass(theme);
  }, [theme]);

  const selectedIndex = selectedProblem
    ? problems.findIndex((problem) => problem.id === selectedProblem.id)
    : -1;

  function handleResetAll() {
    const confirmed = window.confirm(
      "Reset all saved code and solved progress for every problem? This cannot be undone.",
    );

    if (!confirmed) return;

    resetAllProgress();
    setProgressVersion((version) => version + 1);
  }

  if (selectedProblem) {
    return (
      <div className="app-shell">
        <ProblemWorkspace
          key={selectedProblem.id}
          problem={selectedProblem}
          previousProblem={
            selectedIndex > 0 ? problems[selectedIndex - 1] : undefined
          }
          nextProblem={
            selectedIndex >= 0 && selectedIndex < problems.length - 1
              ? problems[selectedIndex + 1]
              : undefined
          }
          onBack={goToList}
          onPrevious={() => {
            if (selectedIndex > 0) {
              navigateToProblem(problems[selectedIndex - 1]);
            }
          }}
          onNext={() => {
            if (selectedIndex >= 0 && selectedIndex < problems.length - 1) {
              navigateToProblem(problems[selectedIndex + 1]);
            }
          }}
          theme={theme}
          onThemeChange={setTheme}
          onProgressChange={() =>
            setProgressVersion((version) => version + 1)
          }
        />
      </div>
    );
  }

  const solvedCount = filteredProblems.filter((problem) =>
    isProblemSolved(problem.id),
  ).length;

  return (
    <div className="app-shell app-home">
      <aside className="sidebar">
        <button className="brand" onClick={goToList}>
          <span className="brand-mark">
            <Brain size={22} />
          </span>
          <span>
            <strong>DSA With Ragu</strong>
            <small>Practice. Learn. Improve.</small>
          </span>
        </button>

        <div className="sidebar-section-label">LEARN</div>

        <nav className="topic-navigation">
          {topics.map((topic) => {
            const Icon = topicIcons[topic] ?? Layers;
            const active = activeTopic === topic;
            const count =
              topic === "All Problems"
                ? problems.length
                : problems.filter((problem) => problem.topic === topic).length;

            return (
              <button
                className={`topic-button ${active ? "active" : ""}`}
                key={topic}
                onClick={() => setActiveTopic(topic)}
              >
                <Icon size={17} />
                <span>{topic}</span>
                <small>{count}</small>
              </button>
            );
          })}
        </nav>

        <div className="sidebar-bottom">
          <div className="theme-control">
            <label htmlFor="home-theme">Appearance</label>
            <select
              id="home-theme"
              value={theme}
              onChange={(event) =>
                setTheme(event.target.value as AppTheme)
              }
            >
              <option value="system">System</option>
              <option value="light">Light</option>
              <option value="dark">Dark</option>
            </select>
          </div>

          <button className="reset-progress-button" onClick={handleResetAll}>
            <Trash2 size={15} />
            Reset all progress
          </button>

          <div className="local-runtime-note">
            <span className="status-dot ready" />
            Runs in your browser
          </div>
        </div>
      </aside>

      <main className="main-content">
        <header className="home-header">
          <div>
            <p className="eyebrow">YOUR PRACTICE SPACE</p>
            <h1>Problem library</h1>
            <p className="page-subtitle">
              Build your problem-solving skills, one challenge at a time.
            </p>
          </div>

          <div className="header-progress">
            <div className="header-progress-icon">
              <CheckCircle2 size={20} />
            </div>
            <div>
              <strong>
                {completedCount} / {problems.length}
              </strong>
              <span>Problems solved</span>
            </div>
          </div>
        </header>

        <section className="stats-grid">
          <div className="stat-card">
            <span>Total problems</span>
            <strong>{problems.length}</strong>
            <small>Available to practice</small>
          </div>
          <div className="stat-card">
            <span>Topics</span>
            <strong>{topics.length - 1}</strong>
            <small>Areas to explore</small>
          </div>
          <div className="stat-card">
            <span>Completed</span>
            <strong>{completedCount}</strong>
            <small>All tests passed</small>
          </div>
          <div className="stat-card">
            <span>Remaining</span>
            <strong>{problems.length - completedCount}</strong>
            <small>Keep going</small>
          </div>
        </section>

        <section className="problem-list-section">
          <div className="problem-list-heading">
            <div>
              <h2>
                {activeTopic === "All Problems" ? "All problems" : activeTopic}
              </h2>
              <p>
                Showing {filteredProblems.length} problems · {solvedCount}{" "}
                solved in this view
              </p>
            </div>

            <label className="problem-search">
              <Search size={17} />
              <input
                value={search}
                onChange={(event) => setSearch(event.target.value)}
                placeholder="Search problems..."
              />
            </label>
          </div>

          <div className="problem-list">
            {filteredProblems.map((problem, index) => {
              const solved = isProblemSolved(problem.id);

              return (
                <article className="problem-card" key={problem.id}>
                  <div className="problem-number">
                    {solved ? (
                      <CheckCircle2 size={19} className="solved-icon" />
                    ) : (
                      <span>{String(index + 1).padStart(2, "0")}</span>
                    )}
                  </div>

                  <div className="problem-card-main">
                    <button
                      className="problem-title-button"
                      onClick={() => navigateToProblem(problem)}
                    >
                      {problem.title}
                    </button>
                    <div className="problem-card-meta">
                      <span>{problem.topic}</span>
                      <span
                        className={`difficulty ${problem.difficulty.toLowerCase()}`}
                      >
                        {problem.difficulty}
                      </span>
                      <span className={solved ? "solved-text" : "unsolved-text"}>
                        {solved ? "Solved" : "Unsolved"}
                      </span>
                    </div>
                  </div>

                  <button
                    className="solve-button"
                    onClick={() => navigateToProblem(problem)}
                  >
                    {solved ? "Review" : "Solve"}
                    <ArrowDownUp size={14} />
                  </button>
                </article>
              );
            })}

            {filteredProblems.length === 0 && (
              <div className="empty-state">
                <Search size={25} />
                <h3>No problems found</h3>
                <p>Try another search term or select a different topic.</p>
                <button
                  className="secondary-button"
                  onClick={() => {
                    setSearch("");
                    setActiveTopic("All Problems");
                  }}
                >
                  Clear filters
                </button>
              </div>
            )}
          </div>
        </section>

        <footer className="home-footer">
          <span>
            <House size={14} />
            DSA With Ragu
          </span>
          <span>Practice consistently. Progress steadily.</span>
        </footer>
      </main>
    </div>
  );
}
